from picamera import PiCamera
from picamera.array import PiRGBArray
from time import sleep
import cv2

camera = PiCamera()
#camera.brightness = 50
def take_image(camera):
	camera.resolution = (640,480)
	rawCapture = PiRGBArray(camera,size=(640,480))
	camera.capture(rawCapture,format="bgr",use_video_port=False)
	image = rawCapture.array
	rawCapture.truncate(0)
	return image

capture_count = 0
print "Focus on Preview Windows, Press 's' to capture an image, 'q' to quit"
while True:
    imgSrc = take_image(camera)
    cv2.imshow("Preview",imgSrc)
    k = cv2.waitKey(1) & 0xFF
    if k == ord("q"):
        break
    sleep(1)
    
cv2.destroyAllWindows()
print("program is end")

