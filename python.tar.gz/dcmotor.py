import RPi.GPIO as io

io.setmode(io.BCM)
dc1_pwm_pin=27
dc1_in1_pin=22
dc1_in2_pin=20

io.setup(dc1_in1_pin,io.OUT)
io.setup(dc1_in2_pin,io.OUT)
io.setup(dc1_pwm_pin,io.OUT)
dc1_pwm=io.PWM(dc1_pwm_pin,50)
dc1_pwm.start(0)
cmd=0


def forward(speed):
	io.output(dc1_in1_pin,True)
	io.output(dc1_in2_pin,False)
	dc1_pwm.start(speed)
	print "forward..."
	return speed

def reverse(speed):
	io.output(dc1_in1_pin,False)
	io.output(dc1_in2_pin,True)
	dc1_pwm.start(speed)
	print "reverse..."
	return speed

def stop(): 
	io.output(dc1_in1_pin,True)
	io.output(dc1_in2_pin,True)
	dc1_pwm.start(0)
	print "stopped!"
	return 0


while cmd!=3:
	try:
		cmd=int(input("enter command, 1-forward, 2-reverse, 3-quit, enter to stop:"))
	except:
		#print "Error"
		stop()

	if cmd==1:
		forward(30)
	elif cmd==2:
		reverse(30)
	elif cmd==3:
		stop()
		break 
	#else :
	#	stop()
