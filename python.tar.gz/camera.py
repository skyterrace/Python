from picamera import PiCamera
from time import sleep

camera = PiCamera()

camera.start_preview()
sleep(10)
for i in range(100):
	camera.brightness = i
	sleep(0.2)
camera.stop_preview()

