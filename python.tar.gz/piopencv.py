import cv2
import time
import numpy as np
from picamera import PiCamera
from picamera.array import PiRGBArray

camera = PiCamera()
camera.resolution = (640,480)
rawCapture = PiRGBArray(camera,size=(640,480))
#rawCapture = PiRGBArray(camera)
time.sleep(0.1)
for frame in camera.capture_continuous(rawCapture, format="bgr",use_video_port=True):
        imgSrc = frame.array

        #cv2.blur(imgSrc, imgSrc,Size(3,3))
        imgHSV = cv2.cvtColor(imgSrc,cv2.COLOR_BGR2HSV)

        lower_blue =  np.array([110,50,50])
        upper_blue = np.array([130,255,255])

        mask = cv2.inRange(imgHSV, lower_blue,upper_blue)
        res = cv2.bitwise_and(imgSrc,imgSrc,mask=mask)

        cv2.imshow('frame',imgSrc)
        #cv2.imshow('mask',mask)
        cv2.imshow('res',res)

        
        k = cv2.waitKey(1) & 0xFF
        rawCapture.truncate(0)
        if k == ord("q"):
                break

cv2.destroyAllWindows()
print("program is end")

