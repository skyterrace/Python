from picamera import PiCamera
from picamera.array import PiRGBArray
from time import sleep
import cv2

camera = PiCamera()
camera.resolution = (640,480)
#camera.brightness = 50
rawCapture = PiRGBArray(camera,size=(640,480))
capture_count = 0
print "Focus on Preview Windows, Press 's' to capture an image, 'q' to quit"
for frame in camera.capture_continuous(rawCapture, format="bgr",use_video_port=True):
    imgSrc = frame.array
    cv2.imshow("Preview",imgSrc)
    k = cv2.waitKey(1) & 0xFF
    if k == ord("q"):
        break
    elif k == ord("s"):
        capture_count+=1
        filename = "image"+format(capture_count,"03d")+".jpg"
        cv2.imwrite(filename,imgSrc)
        imgSrc = cv2.imread(filename)
        cv2.imshow("Saved",imgSrc)
    rawCapture.truncate(0)
    
cv2.destroyAllWindows()
print("program is end")

